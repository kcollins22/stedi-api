//© 2021 Sean Murdock

package com.getsimplex.steptimer.model;

import java.util.Date;

/**
 * Created by sean on 10/7/2016.
 */
public class TestResult {

    private Date date;
    private Long score;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Long getScore() {
        return score;
    }

    public void setScore(Long score) {
        this.score = score;
    }
}
