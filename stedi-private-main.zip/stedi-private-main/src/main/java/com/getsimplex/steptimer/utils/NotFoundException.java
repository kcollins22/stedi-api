//© 2021 Sean Murdock

package com.getsimplex.steptimer.utils;

public class NotFoundException extends Exception{

    public NotFoundException(String messageText){
        super(messageText);
    }
}
