//© 2021 Sean Murdock

package com.getsimplex.steptimer.utils;

public class AlreadyExistsException extends Exception {

    public AlreadyExistsException(String exceptionText){
        super(exceptionText);
    }
}
