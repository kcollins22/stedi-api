//© 2021 Sean Murdock

package com.getsimplex.steptimer.utils;

public class ExpiredException extends Exception{

    public ExpiredException(String messageText){
        super(messageText);
    }
}
