//© 2021 Sean Murdock

package com.getsimplex.steptimer.model;

/**
 * Created by sean on 8/16/2016.
 */
public class MessageSourceTypes {

    public static String DEVICE="DEVICE";
    public static String BROWSER ="BROWSER";
    public static String SERVICE="SERVICE";
}
